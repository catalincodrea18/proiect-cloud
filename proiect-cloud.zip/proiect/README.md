# Proiect Cloud

## Descriere problema

## Arhitectura aplicației

## Instrucțiuni instalare

## Referințe